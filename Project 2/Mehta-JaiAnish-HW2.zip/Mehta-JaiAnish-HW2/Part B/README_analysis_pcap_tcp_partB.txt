EXTERNAL LIBRARIES USED: dpkt,struct
The library dpkt can be installed on windows os using the pip command as shown below:
pip install dpkt
Once the dpkt library will be installed, the code will run by following the steps below.


##############################################################################################################################################################################################################################

INSTRUCTION TO RUN THE PROGRAM for part A: 
To run the program, open the terminal in the folder Mehta-JaiAnish-HW2.
In the terminal type a line as shown below:
python analysis_pcap_tcp_partB.py



Following the above steps will print the output in the terminal.
